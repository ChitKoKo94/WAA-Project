import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';
import { leaveReview } from '../services/RestService';

const ProductDetail = () => {
    const currentItem = useSelector(state => state.currentItem);
    const nav = useNavigate();
    const [orderItem, setOrderItem] = useState(currentItem);
    const [review, setReview] = useState({});
    const dispatch = useDispatch();

    const addItem = () => {
        if (orderItem.product.stock > 0) {
            setOrderItem({ 
                product: {
                    ...orderItem.product,
                    stock: orderItem.product.stock - 1
                }, 
                quantity: orderItem.quantity + 1, 
                totalPrice: 
                parseFloat((currentItem.product.price * (orderItem.quantity + 1)).toFixed(3))
            });
        }
    }

    const removeItem = () => {
        if (orderItem.quantity > 0) {
            setOrderItem({ 
                product: {
                    ...orderItem.product,
                    stock: orderItem.product.stock + 1
                },
                quantity : orderItem.quantity - 1,
                totalPrice: 
                parseFloat((currentItem.product.price * (orderItem.quantity - 1)).toFixed(3))
            });
        }
    }

    const backToProductList = () => {
        if (orderItem.quantity === 0) {
            removeItemFromStore();
        }
        else {
            saveItems();
        }
        nav('/user');
    }

    const goToCart = () => {
        setCurrentItem();
        if (orderItem.quantity === 0) {
            removeItemFromStore();
        }
        else {
            saveItems();
        }
        nav('/cart');
    }

    const removeItemFromStore = () => {
        dispatch({
            type: 'removeItem',
            productNumber: orderItem.product.productNumber
        });
    }

    const setCurrentItem = () => {
        dispatch({
            type: 'setCurrentItem',
            currentItem: orderItem
        });
    }

    const saveItems = () => {
        if (orderItem.quantity > 0) {
            dispatch({
                type: "addItem",
                orderItem: orderItem
            })
        }
    }

    const onChangeReview = (e) => {
        setReview({ ...review, [e.target.name]: e.target.value });
    }

    const submitReview = () => {
        console.log(review);
        leaveReview(orderItem.product.productNumber, review)
            .then(res => {
                setOrderItem({
                    ...orderItem,
                    product: res.data
                });
                setReview({
                    review: '',
                    rating: 1
                });
        });
        
        
    }
  return (
    <>
        <div className='productdetail'>
            <h2 className='productdetail'>Product Detail</h2> <br/>
            <table style={{borderCollapse:'collapse'}} className='productdetail'>
                <tbody>
                    <tr>
                        <td>Product Number: </td>
                        <td>{orderItem.product.productNumber}</td>
                    </tr>
                    <tr>
                        <td>Product Name:</td>
                        <td>{orderItem.product.name}</td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <span id='addItemBtn' className='buttons' onClick={addItem}>Add</span>
                            {orderItem.quantity}
                            <span className='buttons' onClick={removeItem}>Remove</span>
                        </td>
                    </tr>
                </tbody>
            </table>
            <br />
            <div className='backBtn'>
                <button id='gotoCartBtn' onClick={goToCart}>Go to Cart</button>
            </div>
            
        </div> 
        <br />
        <div className='productdetail'>
            <table className='productdetail'>
                <tr>
                    <td>Review</td>
                    <td><textarea onChange={onChangeReview} name='review' value={review.review}/></td>
                </tr>
                <tr>
                    <td>Rating</td>
                    <td><input type='number' min={1} max={5} name='rating' onChange={onChangeReview}
                value={review.rating}/></td>
                </tr>
                <tr>
                    <td colspan="2" style={{textAlign:'center'}}><button  onClick={submitReview}>Submit Review</button></td>
                </tr>
            </table>
            <br />
            <table className='productdetail'>
                <thead>
                    <tr>
                        <th>Review</th>
                        <th>Rating</th>
                    </tr>
                </thead>
                <tbody>
                    {orderItem.product.reviews && orderItem.product.reviews.map(r => 
                        <tr key={r.review}>
                            <td>{r.review}</td>
                            <td>{r.rating}</td>
                        </tr>)}
                </tbody>
            </table>
        </div>
       
        <br />
        <br />
        <div className='backBtn'>
            <button onClick={backToProductList}>Back To Product List</button>
        </div>
        
    </>
  )
}

export default ProductDetail