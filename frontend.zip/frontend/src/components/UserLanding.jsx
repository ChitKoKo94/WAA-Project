import React from 'react'
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { getProduct } from '../services/RestService';


const UserLanding = () => {
    const products = useSelector(state => state.products);
    const cartItems = useSelector(state => state.itemList);
    const dispatch = useDispatch();
    const nav = useNavigate();
    const goToHome = () => {
        nav('/');
    }

    const goToProduct = (e) => {
        const itemExistInCart = cartItems.find(item => item.product.productNumber === e.target.value);
        if (itemExistInCart) {
            dispatch({
                type: 'setCurrentItem',
                currentItem: itemExistInCart
            });
            nav('/productdetail');
        }
        else {
            getProduct(e.target.value)
            .then(res => {
                    console.log(res.data);
                    dispatch({ 
                        type: 'setCurrentItem', 
                        currentItem: {
                            product: res.data[0],
                            quantity: 0,
                            totalPrice: 0
                        }
                    }); 
                nav('/productdetail');
            })
            .catch(err => console.log(err));
        }

    }
  return (
    <>    
        <div className='userpage'>
            <h2>Product List</h2>
            <table className='productListTbl'>
                <thead>
                    <tr>
                        <th>Product Number</th>
                        <th>Product Name</th>
                        <th>Description</th>
                        <th>Price</th>
                    </tr>
                </thead>
                <tbody>
                    {products.map(product => 
                    <tr key={product.id}>
                        <td>
                            <button 
                            id={'gotoProductBtn' + product.productNumber}
                            onClick={goToProduct}
                            value={product.productNumber}>
                                {product.productNumber}
                            </button>
                        </td>
                        <td>{product.name}</td>
                        <td>{product.description}</td>
                        <td>{product.price}</td>
                    </tr>)}
                </tbody>
            </table>
            <div>
                <button id='backHomeBtnUserLanding' onClick={goToHome}>Back To Home</button>
            </div>
        </div>
    </>

  )
}

export default UserLanding