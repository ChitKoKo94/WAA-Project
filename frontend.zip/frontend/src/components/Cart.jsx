import React from 'react'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom';

const Cart = () => {
   const items = useSelector(state => state.itemList);
   const nav = useNavigate();

  return (
    <>    
        <h2 className='productdetail'>Cart</h2> <br/>
        <table className='productdetail'>
            <tr>
                <td>Product name</td>
                <td>Quantity</td>
                <td>Total Price</td>
            </tr>
            {items.map(item => <tr key={item.product.productNumber}>
                <td>{item.product.name}</td>
                <td>{item.quantity}</td>
                <td>{item.totalPrice}</td>
            </tr>)}
        </table>
        <br/>
        <div className='backBtn'>
            <button id='gotoCheckoutBtn' onClick={() => nav('/user-info')}>Go to check out</button>
        </div>
        <div className='backBtn'>
            <button onClick={() => nav('/productdetail')}>Back To Product Detail</button>
        </div>    
    </>

  )
}

export default Cart