import React from 'react'
import { useNavigate } from 'react-router-dom'

const EmployeeLanding = () => {
  const nav = useNavigate();
    return (
    <>
        <div className='mainbtn'>
          <br/>
          <button id='productsBtn' className='mainbuttons' onClick={() => nav('/products')}>Manage Products</button>
          <br />
          <br/>
          <button id='ordersBtn' className='mainbuttons' onClick={() => nav('/orders')}>Manage Orders</button>
          </div>
    </>
  )
}

export default EmployeeLanding