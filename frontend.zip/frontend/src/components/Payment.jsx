import React from 'react'
import { useForm } from 'react-hook-form';
import { useLocation, useNavigate } from 'react-router-dom'
import { saveCheckout } from '../services/RestService';
import { useDispatch } from 'react-redux';

const Payment = () => {
    const location = useLocation();
    const checkoutRecord = location.state;
    const nav = useNavigate();
    const dispatch = useDispatch();
    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const submitPaymentData = (data) => {
        // toISOString -> 2023-11-21T14:40:38.231Z
        // take the date value only before T
        data.date = new Date().toISOString().split("T")[0];
        checkoutRecord.payment = data;
        checkoutRecord.order.status = 'PLACED';
        console.log(checkoutRecord);
        saveCheckout(checkoutRecord)
            .then(res => {
                console.log(res.data);
                dispatch({ type: 'clearCart'});
                alert('Check out Id: ' + res.data.id + ' successful');
                nav('/user');
            })
            .catch(err => console.log(err));
    }
  return (
    <>
    <h2 className='tableDetail'> Payment Detail </h2> <br/>
    <form onSubmit={handleSubmit(submitPaymentData)}>
        <table className='tableDetail'>
            <tbody>
                <tr>
                    <td>Card Type</td>
                    <td>
                        <input type="text"
                            id='type'
                            name='type' 
                            {...register('type', {
                                required: 'Card type is required'
                            })}/>
                    </td>
                </tr>
                {
                    errors.type && 
                    <tr>
                        <td></td>
                        <td style={{ color: 'red'}}>{errors.type.message}</td>
                    </tr>
                }
                <tr>
                    <td>Card Number</td>
                    <td>
                        <input type="text"
                            id='number'
                            name='number' 
                            {...register('number', {
                                required: 'Card number is required',
                                minLength: {
                                    value: 16,
                                    message: 'Card number must be 16 characters'
                                },
                                maxLength: {
                                    value: 16,
                                    message: 'Card number must be 16 characters'
                                }
                            })}/>   
                    </td>
                </tr>
                {
                    errors.number && 
                    <tr>
                        <td></td>
                        <td style={{ color: 'red'}}>{errors.number.message}</td>
                    </tr>
                }
                <tr>
                    <td>Validation Code</td>
                    <td>
                        <input type="text"
                            id='validationCode'
                            name='validationCode' 
                            {...register('validationCode', {
                                required: 'Validation code is required'
                            })}/>
                    </td>
                </tr>
                {
                    errors.validationCode && 
                    <tr>
                        <td></td>
                        <td style={{ color: 'red'}}>{errors.validationCode.message}</td>
                    </tr>
                }
                <tr>
                    <td colSpan={2} style={{ textAlign: 'center'}}>
                        <button id='submitPaymentBtn' type='submit'>Submit</button>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
    </>
  )
}

export default Payment