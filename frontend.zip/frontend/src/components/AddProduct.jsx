import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import { createProduct } from '../services/RestService';

const AddProduct = ({ refreshList }) => {
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm();

    const onSubmit = (data) => {
        console.log(data);
        createProduct(data)
            .then(res => {
                alert('Product: ' + res.data.name + ' successfully created');
                console.log(res.data);
                refreshList();
            })
            .catch(err => console.log(err));

        reset();
    }

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
        <table className='tableDetail'>
            <tbody>
                <tr>
                    <td>Product Number</td>
                    <td>
                        <input type="text" 
                        name='productNumber'
                        id='productNumber'
                        {...register('productNumber', { 
                            required: 'Product number is required',
                            minLength: {
                                value: 5,
                                message: 'Product number must be min 5 characters'
                            }
                        })}/>
                    </td>
                </tr>
                {errors.productNumber && 
                <tr>
                    <td></td>
                    <td className='err'>{errors.productNumber.message}</td>
                </tr>}
                <tr>
                    <td>Product Name</td>
                    <td>
                        <input type="text" 
                        name='name'
                        id='name'
                        {...register('name', { required: 'Name is required'})}/>
                    </td>
                </tr>
                {errors.name && 
                <tr>
                    <td></td>
                    <td className='err'>{errors.name.message}</td>
                </tr>}
                <tr>
                    <td>Price</td>
                    <td>
                        <input type="text" 
                        name='price'
                        id='price'
                        {...register('price', { required: 'Price is required'})}/>
                    </td>
                </tr>
                {errors.price && 
                <tr>
                    <td></td>
                    <td className='err'>{errors.price.message}</td>
                </tr>}
                <tr>
                    <td>Description</td>
                    <td>
                        <input type="text" 
                        name='description'
                        id='description'
                        {...register('description')}/>
                    </td>
                </tr>
                <tr>
                    <td>Stock</td>
                    <td>
                        <input type="number" 
                        name='stock'
                        id='stock'
                        {...register('stock', { 
                            required: 'Stock is required',
                            min: {
                                value: 1,
                                message: 'Stock must be least 1'
                            }
                        })}/>
                    </td>
                </tr>
                {errors.stock && 
                <tr>
                    <td></td>
                    <td className='err'>{errors.stock.message}</td>
                </tr>}
                <tr style={{ textAlign: 'center'}}>
                    <td colSpan={2}>
                        <button id='addProductBtn' type='submit'>Submit</button>
                    </td>
                </tr>
            </tbody>

        </table>
    </form>
  )
}

export default AddProduct