import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { deleteProduct, findAllProducts } from '../services/RestService';
import AddProduct from './AddProduct';
import { useNavigate } from 'react-router-dom';

const Products = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const products = useSelector(state => state.products);
    const [productList, setProductList] = useState(products);

    const remove = (e) => {
        deleteProduct(e.target.value)
            .then(res => {
                alert(res.data);
                refreshProductList();
            });
    }

    const backToHome = () =>{
        navigate("/");
    }

    const refreshProductList = () => {
        findAllProducts()
        .then(res => {
            setProductList(res.data);
            dispatch({ type: 'setProductList', products: res.data });
        })
        .catch(err => console.log(err));
    }

    useEffect(() => {
        refreshProductList();
    }, []);

    const nav = useNavigate();
  return (
    <>    
        <h2 className="productdetail">Product List</h2> <br/>
        <table className="productdetail">
            <thead>
                <tr>
                    <th>Product Number</th>
                    <th>Product Name</th>
                    <th>Description</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                {productList.map(product => 
                <tr key={product.id}>
                    <td id={'numberInList' + product.productNumber}>{product.productNumber}</td>
                    <td id={'nameInList' + product.productNumber}>{product.name}</td>
                    <td>{product.description}</td>
                    <td id={'priceInList' + product.productNumber}>{product.price}</td>
                    <td>
                        <button className="btnClass" onClick={remove} value={product.productNumber}>Remove</button>
                        <button className="btnClass" onClick={() => nav('/editproduct', { state: { product: product}})}>Edit
                        </button>
                    </td>
                </tr>)}
            </tbody>
        </table>
        <br />
        <h2 className="tableDetail">Add Product</h2> <br/>
        <AddProduct refreshList={refreshProductList}/>

        <div className='backBtn'>
            <button id='backHomeProductsBtn' onClick={backToHome}>Back To Home</button>
        </div>
    </>
  )
}

export default Products