import { useForm } from 'react-hook-form';
import { editProduct } from '../services/RestService';
import { useLocation, useNavigate } from 'react-router-dom';
import { useState } from 'react';

const EditProduct = () => {
    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const location = useLocation();
    const nav = useNavigate();
    const data = location.state.product;
    const [productData, setProductData] = useState(data);

    const onSubmit = (data) => {
        editProduct(data)
            .then(res => {
                alert('Product: ' + res.data.name + ' successfully updated');
                nav('/products');
            })
            .catch(err => console.log(err));
    }

    const goToProductList =() =>{
        nav('/products');
    }

  return (
    <>  
        <h2 className='tableDetail'>Edit Product</h2>  <br/>
        <form onSubmit={handleSubmit(onSubmit)}>
            <table className='tableDetail'>
                <tbody>
                    <tr>
                        <td>Product Number</td>
                        <td>
                            <input type="text" 
                            readOnly
                            name='productNumber'
                            value={productData.productNumber}
                            {...register('productNumber', { 
                                required: 'Product number is required',
                                minLength: {
                                    value: 5,
                                    message: 'Product number must be min 5 characters'
                                }
                            })}/>
                        </td>
                    </tr>
                    {errors.productNumber && 
                    <tr>
                        <td></td>
                        <td className='err'>{errors.productNumber.message}</td>
                    </tr>}
                    <tr>
                        <td>Product Name</td>
                        <td>
                            <input type="text" 
                            name='name'
                            defaultValue={productData.name}
                            {...register('name', { required: 'Name is required'})}/>
                        </td>
                    </tr>
                    {errors.name && 
                    <tr>
                        <td></td>
                        <td className='err'>{errors.name.message}</td>
                    </tr>}
                    <tr>
                        <td>Price</td>
                        <td>
                            <input type="text" 
                            name='price'
                            defaultValue={productData.price}
                            {...register('price', { required: 'Price is required'})}/>
                        </td>
                    </tr>
                    {errors.price && 
                    <tr>
                        <td></td>
                        <td className='err'>{errors.price.message}</td>
                    </tr>}
                    <tr>
                        <td>Description</td>
                        <td>
                            <input type="text" 
                            name='description'
                            defaultValue={productData.description}
                            {...register('description')}/>
                        </td>
                    </tr>
                    <tr>
                        <td>Stock</td>
                        <td>
                            <input type="number" 
                            name='stock'
                            defaultValue={productData.stock}
                            {...register('stock', { 
                                required: 'Stock is required',
                                min: {
                                    value: 1,
                                    message: 'Stock must be least 1'
                                }
                            })}/>
                        </td>
                    </tr>
                    {errors.stock && 
                    <tr>
                        <td></td>
                        <td className='err'>{errors.stock.message}</td>
                    </tr>}
                    <tr style={{ textAlign: 'center'}}>
                        <td colSpan={2}>
                            <button type='submit'>Submit</button>
                        </td>
                    </tr>
                </tbody>

            </table>
        </form>
       <div className="backBtn">
        <button  onClick={goToProductList} >Back To Product List</button>
        </div> 
    </>

  )
}

export default EditProduct