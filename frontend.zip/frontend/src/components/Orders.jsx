import React, { useEffect, useState } from 'react'
import { getAllOrders, updateOrderStatus } from '../services/RestService';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';

const Orders = () => {
    const navigate = useNavigate();
    const [checkedOutOrders, setcheckedOutOrders] = useState([]);
    const [sts, changeSts] = useState(false);
    const [orderStatus, setOrderStatus] = useState('');

    useEffect(() => {
        getAllOrders()
        .then(res => setcheckedOutOrders(res.data))
        .catch(err => console.log(err));
    }, [sts]);

    const backToHome = () =>{
        navigate("/");
    }

    const changeStatus = (orderId) => {
        updateOrderStatus(orderId, orderStatus)
            .then(res => { 
                alert('Checked-out order: ' + res.data.id + ' status updated successfully');
                changeSts(!sts);
            })
            .catch(err => console.log(err));
    }

  return (
    <>    
        <h2 className='orderDetail'>Order List</h2> <br/>
        <table className='orderDetail'>
            <thead>
                <tr>
                    <th>Checked-out Order Id</th>
                    <th>Product names</th>
                    <th>Status</th>
                    <th>Total</th>
                    <th>Update Status</th>
                </tr>
            </thead>
            <tbody>
                {checkedOutOrders.map(o => 
                <tr key={o.id}>
                    <td>{o.id}</td>
                    <td name='nameInOrders'>{o.order.items.map(i => i.product.name).join(', ')}</td>
                    <td name='statusInOrders'>{o.order.status}</td>
                    <td name='totalInOrders'>{o.order.total}</td>
                    {o.order.status !== 'DELIVERED' &&
                    <td>
                        <select onChange={(e) => setOrderStatus(e.target.value)}>
                            <option value="">Select Status</option>
                            <option value="PLACED">PLACED</option>
                            <option value="SHIPPED">SHIPPED</option>
                            <option value="DELIVERED">DELIVERED</option>
                        </select>
                        <button onClick={e => changeStatus(o.id)}
                        className='btnUpdate'>Update Status</button>
                    </td>}
                </tr>)}
            </tbody>
        </table>
        <div className='backBtn'>
            <button onClick={backToHome}>Back To Home</button>
        </div>
    </>
  )
}

export default Orders