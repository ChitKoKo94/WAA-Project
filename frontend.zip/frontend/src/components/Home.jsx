import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { findAllProducts } from '../services/RestService';

const Home = () => {
    const nav = useNavigate();
    const dispatch = useDispatch();

    useEffect(() => {
      findAllProducts()
        .then(res => {
            console.log('Loading data in home page', res.data);
            dispatch({ type: 'setProductList', products: res.data });
        })
        .catch(err => console.log(err));
    }, []);

    const goToUserPage = () => nav('/user');
    
  return (
    <>
        <div className='mainbtn'>
          <h2><button id='employeeBtn' className='mainbuttons' onClick={() => nav('/employee')}>EMPLOYEE</button></h2>
          <br/>
          <h2><button id='userBtn' className='mainbuttons' onClick={goToUserPage}>USER</button></h2>
        </div>
    </>
  )
}

export default Home