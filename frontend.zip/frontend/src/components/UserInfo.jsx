import React from 'react'
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { useForm } from "react-hook-form";

const UserInfo = () => {
    const items = useSelector(state => state.itemList);
    const nav = useNavigate();
    const grandTotal = items.map(item => item.totalPrice).reduce((acc, price) => acc + parseFloat(price), 0);

    const {
        register,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const submitUserData = (data) => {
        nav('/payment', { state: {
            order: {
                items: items,
                status: '',
                total: grandTotal
            },
            user: data,
            payment: {}
        }});
    }
  return (
    <>    
        <h2 className='productdetail'>Items</h2><br/>
        <table className='productdetail'>
            <tr>
                <td>Product name</td>
                <td>Quantity</td>
                <td>Total Price</td>
            </tr>
            {items.map(item => <tr key={item.product.productNumber}>
                <td>{item.product.name}</td>
                <td>{item.quantity}</td>
                <td>{item.totalPrice}</td>
            </tr>)}
            <tr>
                <td colSpan={2}>Grand Total</td>
                <td>{grandTotal}</td>
            </tr>
        </table>
        <br/>
        <form onSubmit={handleSubmit(submitUserData)}>
            <table className='tableDetail'>
                <tbody>
                    <tr>
                        <td>Username</td>
                        <td>
                            <input type="text"
                                id='username'
                                name='username' 
                                {...register('username', {
                                    required: 'Username is required',
                                    minLength: {
                                        value: 3,
                                        message: 'Name must be at least 3 characters'
                                    }
                                })}/>
                        </td>
                    </tr>
                    {
                        errors.username && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.username.message}</td>
                        </tr>
                    }
                    <tr>
                        <td>Email</td>
                        <td>
                            <input type="text"
                                id='email'
                                name='email' 
                                {...register('email', {
                                    required: 'Email is required',
                                    pattern: {
                                        value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                                        message: 'Invalid email address',
                                      }
                                })}/>   
                        </td>
                    </tr>
                    {
                        errors.email && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.email.message}</td>
                        </tr>
                    }
                    <tr>
                        <td>Phone</td>
                        <td>
                            <input type="text"
                                id='phone'
                                name='phone' 
                                {...register('phone', {
                                    required: 'Phone is required'
                                })}/>
                        </td>
                    </tr>
                    {
                        errors.phone && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.phone.message}</td>
                        </tr>
                    }
                    <tr>
                        <td>City</td>
                        <td>
                            <input type="text"
                                id='city'
                                name='city' 
                                {...register('city', {
                                    required: 'City is required'
                                })}/>
                        </td>
                    </tr>
                    {
                        errors.city && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.city.message}</td>
                        </tr>
                    }
                    <tr>
                        <td>Street</td>
                        <td>
                            <input type="text"
                                id='street'
                                name='street' 
                                {...register('street', {
                                    required: 'Street is required'
                                })}/>
                        </td>
                    </tr>
                    {
                        errors.street && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.street.message}</td>
                        </tr>
                    }
                    <tr>
                        <td>Zip</td>
                        <td>
                            <input type="text"
                                id='zip'
                                name='zip' 
                                {...register('zip', {
                                    required: 'Zip is required'
                                })}/>
                        </td>
                    </tr>
                    {
                        errors.zip && 
                        <tr>
                            <td></td>
                            <td style={{ color: 'red'}}>{errors.zip.message}</td>
                        </tr>
                    }
                    <tr>
                        <td colSpan={2} style={{ textAlign: 'center'}}>
                            <button id='submit' type='submit'>Submit</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </form>
        <br/>
    </>
  )
}

export default UserInfo