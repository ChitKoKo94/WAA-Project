import logo from './logo.svg';
import './App.css';
import Home from './components/Home';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import UserLanding from './components/UserLanding';
import EmployeeLanding from './components/EmployeeLanding';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import UserInfo from './components/UserInfo';
import Payment from './components/Payment';
import Orders from './components/Orders';
import Products from './components/Products';
import EditProduct from './components/EditProduct';

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />}/>
          <Route path='/user' element={<UserLanding />}/>
          <Route path='/employee' element={<EmployeeLanding />}/>
          <Route path='/productdetail' element={<ProductDetail />} />
          <Route path='/cart' element={<Cart />} />
          <Route path='/user-info' element={<UserInfo />} />
          <Route path='/payment' element={<Payment />} />
          <Route path='/orders' element={<Orders />} />
          <Route path='/products' element={<Products />} />
          <Route path='/editproduct' element={<EditProduct />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
