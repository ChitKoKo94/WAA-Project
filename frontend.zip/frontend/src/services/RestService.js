import axios from 'axios'

const baseURL = 'http://localhost:8080';

export const saveCheckout = (checkoutRecord) => {
    return axios.post(baseURL + '/checkout', checkoutRecord);
}

export const leaveReview = (productNumber, review) => {
    return axios.put(baseURL + '/products/reviews/' + productNumber, review);
}

export const getProduct = (productNumber) => {
    return axios.get(baseURL + '/products/search?number=' + productNumber);
}

export const deleteProduct = (productNumber) => {
    return axios.delete(baseURL + '/products/' + productNumber);
}

export const findAllProducts = () => {
    return axios.get(baseURL + '/products');
}

export const createProduct = (product) => {
    return axios.post(baseURL + '/products', product);
}

export const editProduct = (product) => {
    return axios.put(baseURL + '/products', product);
}

export const getAllOrders = () => {
    return axios.get(baseURL + '/checkout');
}

export const updateOrderStatus = (checkoutId, status) => {
    return axios.put(baseURL + '/checkout/' + checkoutId + '/' + status);
}