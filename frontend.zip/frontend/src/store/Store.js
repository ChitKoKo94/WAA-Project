import { configureStore } from "@reduxjs/toolkit";

const productReducer = (state = { products: [], currentItem: {}, itemList: [] }, action) => {
    if (action.type === 'setProductList') {
        return { 
            products: action.products, 
            currentItem: state.currentItem,
            itemList: state.itemList
        };
    }
    if (action.type === 'setCurrentItem') {
        return { 
            products: state.products, 
            currentItem: action.currentItem,
            itemList: state.itemList
        };
    }
    if (action.type === 'addItem') {
        let existingItem = state.itemList.find(item => item.product.productNumber === action.orderItem.product.productNumber);
        console.log('existing item', existingItem);
        if (existingItem) {
            let updatedItem = { 
                ...existingItem,
                quantity: action.orderItem.quantity,
                totalPrice: action.orderItem.totalPrice
            };
            console.log('updated', updatedItem);
            return {
                ...state,
                itemList: [
                    ...state.itemList.filter(i => i.product.productNumber !== action.orderItem.product.productNumber),
                    updatedItem
                ]
            };
        }
        return { 
            products: state.products, 
            currentItem: state.currentItem, 
            itemList: [ ...state.itemList, action.orderItem ]
        };
    }
    if (action.type === 'removeItem') {
        return {
            ...state,
            itemList: state.itemList.filter(i => i.product.productNumber !== action.productNumber)
        }
    }
    if (action.type === 'clearCart') {
        return {
            ...state,
            currentItem: {
                ...state.currentItem,
                quantity: 0,
                totalPrice: 0
            },
            itemList: []
        };
    }
    return state;
}

const store = configureStore({ reducer: productReducer });

export default store;