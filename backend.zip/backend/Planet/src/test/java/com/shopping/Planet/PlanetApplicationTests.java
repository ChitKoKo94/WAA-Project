package com.shopping.Planet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlanetApplicationTests {

	@Test
	void contextLoads() {
	}

}
