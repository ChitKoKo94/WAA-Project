package com.shopping.Planet.Domain;

public enum OrderStatus {
    PLACED, SHIPPED, DELIVERED
}
